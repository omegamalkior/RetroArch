# gpSP ARM dynarec speedups (3DS-focused, works on every 32-bit ARM)

Patch against libretro/gpsp `5819380` ("Keep the PSG status bits readable in SOUNDCNT_X").
Touches only `arm/arm_emit.h`, `arm/arm_stub.S` and `cpu_threaded.c`. ARMv5, ARMv6K (3DS) and
ARMv7 builds all use it. The ARM64, x86 and MIPS backends are unaffected, except for two small
fixes in shared code (both explained below).

```
git apply gpsp-arm-dynarec-speedups.patch
```

## Results

These are estimated ARM11 (3DS CPU) cycles per emulated frame, from an instruction-level ARM
emulator with a simple ARM11 cost model. That means branch prediction (a 128-entry BHT and a
3-entry return stack), mispredict penalties, load-use stalls and multi-cycle ops. Caches are
not modelled. Each run is 300 frames with the dynarec on.

| ROM | original | patched | change |
|---|---:|---:|---:|
| bench (synthetic "commercial-like" workload, see tools/) | 3,021,373 | 2,581,915 | **-14.5%** |
| dezgex (homebrew) | 1,599,573 | 1,380,727 | -13.7% |
| cebelix (homebrew) | 1,346,982 | 1,217,913 | -9.6% |
| mysticq (homebrew) | 1,536,983 | 1,410,448 | -8.2% |
| arkanoid (homebrew) | 1,600,272 | 1,474,183 | -7.9% |
| maze (homebrew) | 1,911,099 | 1,779,031 | -6.9% |
| ravenx (homebrew) | 1,997,807 | 1,880,647 | -5.9% |
| ld46 (homebrew) | 2,163,669 | 2,126,064 | -1.7% |

These totals include the scanline renderer, which is unchanged. It is now about 2/3 of the
time on `bench`. The CPU-emulation side alone (everything that isn't rendering) went from about
1.28M to 0.82M cycles/frame on `bench`, which is **about 36% less work**.

The real-hardware gain will differ. Caches aren't modelled, and translated code is larger (see
"Code size").

## What changed

### Speedups

1. **Indirect branch target cache (IBTC)** in `arm_stub.S`. Before, every guest indirect branch
   called `block_lookup_address_*` in C: that's every `bx lr`, every `pop {pc}`, every jump table
   and every Thumb/ARM interworking branch. Now a 1024-entry `{guest pc|mode -> host block}` table
   is probed in assembly first, and the C lookup only runs on a miss. The table is wiped in
   `flush_translation_cache_ram/rom()` and `init_dynarec_caches()`. Keys are `pc|1` (Thumb) and
   `(pc&~3)|2` (ARM), so a zeroed entry can never match.
2. **Memory handlers return with `bx lr`** instead of `add pc, lr, #4`. A non-`bx lr` return is
   never predicted, and on Cortex-A cores it also desyncs the return stack. The generated code
   now jumps over the PC word with a `b`, which the CPU predicts, and the handlers read the PC
   word at `[lr, #4]`.
3. **Inline fast path for LDM/STM/PUSH/POP** (Thumb and ARM). The old code called one handler
   per register. Now the generated code checks once that the whole transfer stays inside a
   single 32 KB page of IWRAM or EWRAM. For stores it also checks that all SMC tags are zero.
   If so, it does native `ldr`/`str`. Otherwise it falls back to the old code, which is left
   unchanged, so the SMC/IO/mirror semantics are identical.
4. **Inline IWRAM fast path for single loads/stores** (Thumb everywhere; ARM only when the code
   runs from RAM or the base register is SP). EWRAM accesses and the regular handler call are
   moved out of line into "cold" stubs at the end of the block. That keeps the hot code about
   as big as the old call sequence, which matters for the 3DS's 16 KB I-cache. The address
   check also catches misalignment, so unaligned accesses (rotations etc.) still go through the
   handlers. Stores check SMC tags before writing. For Thumb code, the existing dead-flag pass
   now also records which flags are live *after* each instruction (bits 12-15 of `flag_data`).
   Flags are saved and restored with MRS/MSR only when they're live.
5. **Cycle check at block exits** uses `mrs / cmp / bmi / msr`, which the CPU predicts, instead
   of the computed jump `add pc, pc, r0, lsl #3`.

6. **Faster brighten/darken merge** in `video.cc` (all platforms). Fades are common, and the
   merge was one of the hottest loops. It now works on two pixels per 32-bit word and reuses the
   result while the pair repeats. The output is the same per pixel. The same reuse in the alpha-blend
   merge was tried and dropped: it slowed scenes whose blended pixels change every pixel.

7. **Skip idle serial updates** in `main.c`/`serial.h` (all platforms). `update_serial()` ran on
   every hardware event even with no link device and no serial IRQ pending, where it does nothing.
   A cheap inline check now skips the call in exactly that case.

### Bug fixes found along the way

* **The first RAM block after a flush was re-translated on every lookup.** RAM tag entries
  store the block offset, and 0 means "not translated", but the first block emitted into the
  RAM cache is at offset 0. Typically that block is the game's IWRAM sound mixer. Fix: RAM blocks
  now start at offset 16 (`RAM_CACHE_START_OFFSET`). This lives in shared code, so it applies to
  every backend.
* **The SWI div helper code was never cache-synced** on platforms with range-based cache sync
  (Linux/Android ARM). `init_bios_hooks()` set `last_rom_translation_ptr` past the helpers that
  `init_emitter()` had just written. This was harmless on the 3DS, which flushes the whole cache.
* **`ext_store_ignore` returned one instruction too far for "safe" stores** (STM/PUSH to
  BIOS/ROM). It's fixed by item 2: all handlers now return with `bx lr`.
* `write32()` is now a single expression, so `if (x) ARM_FOO(...);` can no longer silently run
  half of the macro. No existing code hit this, but my new code did before I caught it.

## How it was tested

There was no 3DS or ARM board available, so everything ran through a small user-mode ARM Linux
emulator written for this (`tools/armemu.c`). It supports ARMv5/v6K/v7 A32 and EABI syscalls,
has the ARM11 cost model and a per-function profiler, and **flags any translated code executed
before an icache flush**. That flag is how the div-helper bug was found. gpSP plus a headless
libretro frontend (`tools/harness`) are cross-compiled with clang against musl.

* The emulator is validated against native x86 builds: the interpreter (`gpsp_drc=disabled`)
  produces bit-identical video and audio hashes.
* Patched vs. unpatched ARM dynarec (with the offset fix applied to the reference):
  **bit-identical video+audio hashes** on 14 ROMs × 600 frames for ARMv6K. ARMv5 and ARMv7 were
  checked too, plus 3000-frame soak runs and a build with tiny translation caches (192 KB / 64 KB)
  that flushes constantly. Zero stale-code errors.
* `tools/gbabench/torture.c` is a test ROM aimed at the new paths. It covers self-modifying code
  in IWRAM/EWRAM via strb/strh/str/stmia/DMA, unaligned and mirrored accesses,
  LDM/STM crossing the 32 KB mirror boundary, and NZCV surviving loads/stores/push/pop between
  `cmp` and a conditional branch, in both Thumb and ARM.
* The x86 build is bit-identical before and after, in both dynarec and interpreter modes.
* It compiles in the real 3DS configuration (`-D_3DS -DARM11 -march=armv6k -mtune=mpcore
  -mfloat-abi=hard`, fixed-address caches) and for ARMv5TE.

**Not tested:** real hardware or commercial ROMs. Please test on a 3DS (or Azahar) with real
games before shipping.

## Code size

Translated code is about 2.3× larger overall (bench: ROM cache 42 KB → 98 KB, RAM cache
3 KB → 8 KB). Most of the growth is in the cold stubs at the end of each block. The 10 MB ROM
cache has plenty of room. The RAM cache (512 KB, or 384 KB with `SMALL_TRANSLATION_CACHE`)
will flush sooner in games that run a lot of code from EWRAM. Building with
`-DMEMFAST_SINGLE=0` disables optimization 4 if that turns out to be an issue.

## Ideas not done

* The renderer (`video.cc`) is now the main cost, mostly in `render_w_effects`/`merge_blend`
  and the tile renderers. Forcing `render_tile_Nbpp` inline didn't help.
* ARM-mode flag liveness, so ARM-mode fast paths could skip MRS/MSR.
* On the 3DS, `ctr_flush_invalidate_cache()` cleans and invalidates the *entire* caches after
  every new translation. A range-based flush through the kernel backdoor would be cheaper, but it
  can't be tested without hardware.
* Automatic idle-loop detection for games that busy-poll VCOUNT. That's a big win for those
  games, but it changes timing, so it needs per-game validation.

## tools/

* `armemu.c`: the ARM emulator. `-p` profiles, `-n` disables the JIT-coherency check. Env vars:
  `PCPROF=<symbol>`, `INDHIST=1`, `DUMPSYM=sym,off,len`.
* `harness/`: the headless libretro runner (dlopen and static variants). It hashes every
  frame and can dump the last frame (`DUMP_PPM=`).
* `build.sh` / `check.sh` / `perf.sh`: cross-build plus regression and perf scripts. They need
  clang/lld plus musl and compiler-rt builtins built for `arm-linux-musleabi`, soft-float.
* `gbabench/`: `bench.gba` and `torture.gba`, with sources. Build with clang
  `--target=armv4t-none-eabi -mthumb` and lld using `gba.ld`.
