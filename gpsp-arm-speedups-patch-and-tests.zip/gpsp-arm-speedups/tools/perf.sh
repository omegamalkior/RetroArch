#!/bin/bash
# perf.sh <build> -- estimated ARM11 cycles per frame (no hashing) on bench + 2 games
B=$1
cd /home/claude/roms
for r in bench arkanoid ravenx; do
  c=$(NOHASH=1 /home/claude/armemu/armemu -n /home/claude/armbuild/$B $r.gba 300 enabled 2>&1 >/dev/null | grep -o 'est_arm11_cycles=[0-9]*' | cut -d= -f2)
  echo "$r $((c/300))"
done
