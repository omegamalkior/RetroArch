#!/bin/bash
# build.sh <srcdir> <outname> <march>   -> static ARM linux ELF with gpsp + harness
set -e
SRC=$1; OUT=$2; MARCH=${3:-armv6k}
SYS=/home/claude/tools/armsys
CFLAGS="--target=arm-linux-musleabi -march=$MARCH -marm -mfloat-abi=soft -O2 -nostdinc -isystem $SYS/include -isystem /usr/lib/llvm-18/lib/clang/18/include -ffunction-sections -fno-strict-aliasing -w"
DEFS="$EXTRA -DARM_ARCH -DHAVE_DYNAREC -DMMAP_JIT_CACHE -D__LIBRETRO__ -DINLINE=inline -DFRONTEND_SUPPORTS_RGB565 -DNDEBUG -DHAVE_STDINT_H -DHAVE_INTTYPES_H -DHAVE_STRINGS_H"
INC="-I$SRC/libretro -I$SRC/libretro/libretro-common/include -I$SRC"
OBJ=/tmp/obj_$OUT; rm -rf $OBJ; mkdir -p $OBJ; rm -f $OUT
CSRC="main.c gba_memory.c savestate.c input.c sound.c cheats.c memmap.c serial.c gbp.c rfu.c serial_proto.c libretro/libretro.c gba_cc_lut.c cpu_threaded.c
libretro/libretro-common/compat/compat_posix_string.c libretro/libretro-common/compat/compat_strl.c libretro/libretro-common/compat/fopen_utf8.c libretro/libretro-common/encodings/encoding_utf.c libretro/libretro-common/file/file_path.c libretro/libretro-common/file/file_path_io.c libretro/libretro-common/streams/file_stream.c libretro/libretro-common/string/stdstring.c libretro/libretro-common/time/rtime.c libretro/libretro-common/vfs/vfs_implementation.c"
pids=()
for f in $CSRC; do clang $CFLAGS $DEFS $INC -c $SRC/$f -o $OBJ/$(echo $f | tr / _).o & pids+=($!); if [ ${#pids[@]} -ge 2 ]; then wait ${pids[0]}; pids=(${pids[@]:1}); fi; done
for f in video.cc cpu.cc; do clang++ $CFLAGS $DEFS $INC -fno-rtti -fno-exceptions -std=c++11 -nostdinc++ -c $SRC/$f -o $OBJ/$f.o; done
for f in arm/arm_stub.S bios_data.S; do clang $CFLAGS $DEFS $INC -c $SRC/$f -o $OBJ/$(echo $f | tr / _).o; done
wait
clang $CFLAGS -I/home/claude/gpsp-base/libretro/libretro-common/include -DSTATIC_CORE -c /home/claude/harness/run_static.c -o $OBJ/harness.o
ld.lld -static -o $OUT $SYS/lib/crt1.o $SYS/lib/crti.o $OBJ/*.o --start-group $SYS/lib/libc.a $SYS/lib/libm.a $SYS/lib/libbuiltins.a --end-group $SYS/lib/crtn.o
echo built $OUT
