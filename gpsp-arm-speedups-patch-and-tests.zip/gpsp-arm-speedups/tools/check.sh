#!/bin/bash
# check.sh <build>  -- compare against base_v6 on all ROMs (600 frames), report mismatches + jit errors
B=$1; F=${2:-600}
cd /home/claude/roms
fail=0
for r in bench torture torture_x arm thumb memory arkanoid cebelix dezgex ld46 maze mysticq ravenx stripes; do
  ref=/tmp/ref_${REF:-basefix_v6}_${r}_$F.txt
  if [ ! -f $ref ]; then /home/claude/armemu/armemu /home/claude/armbuild/${REF:-basefix_v6} $r.gba $F enabled 2>/dev/null > $ref; fi
  out=$(/home/claude/armemu/armemu /home/claude/armbuild/$B $r.gba $F enabled 2>/tmp/chk_err)
  je=$(grep -o 'jit_errors=[0-9]*' /tmp/chk_err); un=$(grep "armemu: [a-z]" /tmp/chk_err | grep -v "exit=" | head -1)
  if [ "$out" != "$(cat $ref)" ] || [ -n "$un" ]; then echo "MISMATCH $r: $out vs $(cat $ref) $un"; fail=1; fi
  case $r in arm|thumb) ;; *) if [ "$je" != "jit_errors=0" ]; then echo "JITERR $r $je"; fail=1; fi;; esac
done
[ $fail = 0 ] && echo "ALL OK ($B)"
